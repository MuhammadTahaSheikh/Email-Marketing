import React, { useState } from 'react';
import '../../Components/Testimonials/TestimonialsEmail.css';
import test from "../../Assets/test_img.png"
function TestimonialsEmail() {
  const testimonials = [
    // Add your testimonials data here
    {
      name: "Bruce Hardy",
      role: "Software Developer",
      image: "https://i.imgur.com/PKHvlRS.jpg",
      content: "“I was less than 2 months from losing my home because I was behind on my payments… Spencer came in and payed a fair price for my home and gave me extra time to move out after I received the money. He went above and beyond to help me out”",
      stars: 5,
      starColor: "yellow",
    },
 
    {
      name: "Bruce Hardy1",
      role: "Software Developer",
      image: "https://i.imgur.com/PKHvlRS.jpg",
      content: "“I was less than 2 months from losing my home because I was behind on my payments… Spencer came in and payed a fair price for my home and gave me extra time to move out after I received the money. He went above and beyond to help me out”",
      stars: 3,
      starColor: "yellow",
    },
    {
      name: "Bruce Hardy2",
      role: "Software Developer",
      image: "https://i.imgur.com/PKHvlRS.jpg",
      content: "“I was less than 2 months from losing my home because I was behind on my payments… Spencer came in and payed a fair price for my home and gave me extra time to move out after I received the money. He went above and beyond to help me out”",
      stars: 4,
      starColor: "yellow",
    },
    {
      name: "Bruce Hardy3",
      role: "Software Developer",
      image: "https://i.imgur.com/PKHvlRS.jpg",
      content: "“I was less than 2 months from losing my home because I was behind on my payments… Spencer came in and payed a fair price for my home and gave me extra time to move out after I received the money. He went above and beyond to help me out”",
      stars: 4,
      starColor: "yellow",
    },
    
    {
      name: "Bruce Hardy4",
      role: "Software Developer",
      image: "https://i.imgur.com/PKHvlRS.jpg",
      content: "“I was less than 2 months from losing my home because I was behind on my payments… Spencer came in and payed a fair price for my home and gave me extra time to move out after I received the money. He went above and beyond to help me out”",
      stars: 3,
      starColor: "yellow",
    },
    {
      name: "Bruce Hardy5",
      role: "Software Developer",
      image: "https://i.imgur.com/PKHvlRS.jpg",
      content: "“I was less than 2 months from losing my home because I was behind on my payments… Spencer came in and payed a fair price for my home and gave me extra time to move out after I received the money. He went above and beyond to help me out”",
      stars: 4,
      starColor: "yellow",
    },
    {
      name: "Bruce Hardy6",
      role: "Software Developer",
      image: "https://i.imgur.com/PKHvlRS.jpg",
      content: "“I was less than 2 months from losing my home because I was behind on my payments… Spencer came in and payed a fair price for my home and gave me extra time to move out after I received the money. He went above and beyond to help me out”",
      stars: 4,
      starColor: "yellow",
    },
    // Add more testimonials objects as needed
  ];

  const testimonialsPerPage = 3; 
  const [currentPage, setCurrentPage] = useState(1);
  const totalTestimonials = testimonials.length;
  const totalPages = Math.ceil(totalTestimonials / testimonialsPerPage);

  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  const indexOfLastTestimonial = currentPage * testimonialsPerPage;
  const indexOfFirstTestimonial = indexOfLastTestimonial - testimonialsPerPage;
  const currentTestimonials = testimonials.slice(indexOfFirstTestimonial, indexOfLastTestimonial);
  const getPageNumbers = () => {
    const dots = '\u2022';
    const pageNumbers = [];

    for (let i = 1; i <= totalPages; i++) {
      pageNumbers.push(i === currentPage ?<h1 className='check'>{dots}</h1>  : <h1 className='unncheck'>{dots}</h1>);
    }

    return pageNumbers;
  };

  return (
    <div>
      <div className="container mt-5 mb-5">
     
      <div className="row d-flex justify-content-center">
        <div className="col-md-10 col-xl-8 text-center mb-5">
          <h3 className="fw-bold mb-4 testi_heading">Testimonials</h3>
        </div>
      </div>
        <div className="row g-2">
          {currentTestimonials.map((testimonial, index) => (
            <div className="col-md-4 card1" key={index}>
              <div className="card p-3 text-center px-4">
                <div className="user-image">
                  <img src={test} className="rounded-circle" width="80" alt={testimonial.name} />
                </div>
                <div className="user-content">
                <p className='text-white'>{testimonial.content}</p>
                <hr className='text-white'/>
                  <h5 className="mb-0 text-white text-left">{testimonial.name}</h5>
                  <span className='text-white float-left'>{testimonial.role}</span>
                  <span className="ratings float-right">
  {Array.from({ length: testimonial.stars }).map((_, index) => (
    <i className="fa fa-star" style={{ color: testimonial.starColor }} key={index}></i>
  ))}
</span>
                </div>
               
              </div>
            </div>
          ))}
        </div>
        <nav aria-label="Page navigation">
        <ul className="pagination justify-content-center mt-3">
            {getPageNumbers().map((item, index) => (
              <li className={`page-item ${currentPage === index + 1 ? 'active' : ''}`} key={index}>
                <button className="page-link" onClick={() => handlePageChange(index + 1)}>{item}</button>
              </li>
            ))}
          </ul>
        </nav>
      </div>
    </div>
  );
}

export default TestimonialsEmail;