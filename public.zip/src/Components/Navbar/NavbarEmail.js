import React, { useState, useEffect } from "react";
import { Link, Route, Switch } from "react-router-dom"; // Import necessary components from react-router-dom
import SignIn from "../SignInUp/SignIn";
import SignUp from "../SignInUp/SignUp";
import "../Navbar/NavbarEmail.css";

import ModalSignIn from "../SignInUp/ModalSignIn";
import ModalSignUp from "../SignInUp/ModalSignUp";

function NavbarEmail() {
  const [modalIsOpen, setModalIsOpen] = useState(false);

  const openModal = () => setModalIsOpen(true);
  const closeModal = () => setModalIsOpen(false);

  const [modalIsOpen1, setModalIsOpen1] = useState(false);

  const openModal1 = () => setModalIsOpen1(true);
  const closeModal1 = () => setModalIsOpen1(false);
  const [activeButton, setActiveButton] = useState(null);



  useEffect(() => {
    function handleNavItemClick(event) {
      const clickedLink = event.target;
      const navLinks = document.querySelectorAll(".nav-link");

      navLinks.forEach((link) => {
        link.classList.remove("active");
      });

      clickedLink.classList.add("active");
    }

    const navLinks = document.querySelectorAll(".nav-link");
    navLinks.forEach((link) => {
      link.addEventListener("click", handleNavItemClick);
    });

    return () => {
      navLinks.forEach((link) => {
        link.removeEventListener("click", handleNavItemClick);
      });
    };
  }, []);

  return (
    <div className="background_img">
    
      <nav className="navbar navbar-expand-lg navbar-light abc">
      <button
      className="navbar-toggler"
      type="button"
      data-toggle="collapse"
      data-target="#navbarText"
      aria-controls="navbarText"
      aria-expanded="false"
      aria-label="Toggle navigation"
    >
      <span className="navbar-toggler-icon"></span>
    </button>
        <div className="collapse navbar-collapse" id="navbarText">
          <ul className="navbar-nav mr-auto container">
            <li className="nav-item active">
              <Link to="/" className="nav-link header_value">
                HOME
              </Link>       
            </li>
            <li className="nav-item">
              <a className="nav-link header_value" href="#packages">
                PACKAGES
              </a>
            </li>
            <li className="nav-item">
              <a className="nav-link header_value" href="#reviews">
                REVIEWS
              </a>
            </li>
          </ul>
        </div>

        <div className="navbar-nav px-5 ml-auto w-50 justify-content-end gap-1">

        <button className="btn_value1 pt-2 pb-2" onClick={openModal}>Sign in</button>
        <ModalSignIn isOpen={modalIsOpen} onClose={closeModal}/>
        <button className="btn_value1" onClick={openModal1}>Sign up</button>
        <ModalSignUp isOpen={modalIsOpen1} onClose={closeModal1}/>
      </div>
    </nav>

                                     
  </div>
  );
}

export default NavbarEmail;
