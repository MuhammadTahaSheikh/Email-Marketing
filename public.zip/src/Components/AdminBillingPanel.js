import React from 'react'
import BillingHistoryNav from './BillingEmailMarketing/BillingHistoryNav'
import BillingHistoryRecord from './BillingEmailMarketing/BillingHistoryRecord'
import BillingHistoryUserTable from './BillingEmailMarketing/BillingHistoryUserTable'

function AdminBillingPanel() {
  return (
    <div>
      <BillingHistoryNav/>
      <BillingHistoryRecord/>
      <BillingHistoryUserTable/>
    </div>
  )
}

export default AdminBillingPanel
