import React from 'react'
import "../BillingEmailMarketing/BillingHistoryRecord.css"
function BillingHistoryRecord() {
  return (
    <div className='record_main'>
    <div className='container pt-5 pb-5'>
    <div className='row'>
    <div className='col-9'>
    <h2 className='ad_panel'>Billing History</h2>
    </div>
    <div className='col-3'>
    <div><span className='users_cont'>Total Users:</span><span className='users_amt'>2000</span></div>
    <div><span className='users_cont'>Active Users:</span><span className='users_amt'>2000</span></div>
    
    </div>
    </div>
    </div>
    </div>
  )
}

export default BillingHistoryRecord
