import React from 'react'
import BillingHistoryNav from './BillingHistoryNav'
import BillingHistoryRecord from './BillingHistoryRecord'
import BillingHistoryUserTable from './BillingHistoryUserTable'

function BillingHistory() {
  return (
    <div>
      <BillingHistoryNav/>
      <BillingHistoryRecord/>
      <BillingHistoryUserTable/>
    </div>
  )
}

export default BillingHistory
