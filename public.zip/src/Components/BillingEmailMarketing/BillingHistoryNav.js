import React from 'react'
import "../BillingEmailMarketing/BillingHistoryNav.css"

import signout from "../../Assets/signout.png";
import img from "../../Assets/test_img.png";
import edit_btn from "../../Assets/Edit_Button.png"
import "../AdminPanelEmailMarketing/AdminPanelMain.css"
function BillingHistoryNav() {
  return (
    <div>
          
    <div className='user_main_admin'>
    <div className="container back_img">
     
      <div className="flex-container">
        <div className="flex-grow"></div> 
      
        <div className="profile-info">
        
            <img src={img} alt="User Profile" className='user_profile_admin' />
          
        
        </div>
        <div className=''>
        <span className="text-white ml-3">Muhammad Taha</span>
        <a href="/editProfile" className="text-white d-block ml-3 edit_btn"><span><img src={edit_btn}/></span>Edit Profile</a>
        </div>
 
        
   
        <div className="straight-line_nav"></div>
        {/* Signout button */}
        <button className="signout-button_adm text-white"> <span className="signout"><img src={signout} alt="Signout" /></span>Log Out</button>
      </div>
    </div>


    </div>
    </div>
  )
}

export default BillingHistoryNav
