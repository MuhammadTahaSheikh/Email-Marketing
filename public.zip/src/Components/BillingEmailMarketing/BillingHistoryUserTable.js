import React, {useState } from 'react';


import { Link } from 'react-router-dom';
import card from "../../Assets/card.png";
import "../BillingEmailMarketing/BillingHistoryUserTable.css"
import signout from "../../Assets/signout.png";
import img from "../../Assets/test_img.png";
import edit_btn from "../../Assets/Edit_Button.png"

function BillingHistoryUserTable() {


    const billingHistoryData = [
        { date: 'Nov 03, 2023', time: '06:50 PM', cardNumber: '**** 4231', amount: '$153.00', status: 'Paid' },
        { date: 'Nov 05, 2023', time: '07:50 PM', cardNumber: '**** 1453', amount: '$173.00', status: 'Denied' },
        { date: 'Dec 03, 2023', time: '08:50 PM', cardNumber: '**** 4231', amount: '$153.00', status: 'Paid' },
        { date: 'Jan 03, 2023', time: '09:50 PM', cardNumber: '**** 1453', amount: '$183.00', status: 'Pending' },
        { date: 'Nov 03, 2023', time: '06:50 PM', cardNumber: '**** 4231', amount: '$153.00', status: 'Paid' },
        { date: 'Nov 05, 2023', time: '07:50 PM', cardNumber: '**** 1453', amount: '$173.00', status: 'Denied' },
        { date: 'Dec 03, 2023', time: '08:50 PM', cardNumber: '**** 4231', amount: '$153.00', status: 'Paid' },
        { date: 'Jan 03, 2023', time: '09:50 PM', cardNumber: '**** 1453', amount: '$183.00', status: 'Pending' },
        { date: 'Nov 03, 2023', time: '06:50 PM', cardNumber: '**** 4231', amount: '$153.00', status: 'Paid' },
        { date: 'Nov 05, 2023', time: '07:50 PM', cardNumber: '**** 1453', amount: '$173.00', status: 'Denied' },
        { date: 'Dec 03, 2023', time: '08:50 PM', cardNumber: '**** 4231', amount: '$153.00', status: 'Paid' },
        { date: 'Jan 03, 2023', time: '09:50 PM', cardNumber: '**** 1453', amount: '$183.00', status: 'Pending' },
        { date: 'Nov 03, 2023', time: '06:50 PM', cardNumber: '**** 4231', amount: '$153.00', status: 'Paid' },
        { date: 'Nov 05, 2023', time: '07:50 PM', cardNumber: '**** 1453', amount: '$173.00', status: 'Denied' },
        { date: 'Dec 03, 2023', time: '08:50 PM', cardNumber: '**** 4231', amount: '$153.00', status: 'Paid' },
        { date: 'Jan 03, 2023', time: '09:50 PM', cardNumber: '**** 1453', amount: '$183.00', status: 'Pending' }
      ];
      const itemsPerPage = 10; // Number of items per page
      const [currentPage, setCurrentPage] = useState(1);
      
      const indexOfLastItem = currentPage * itemsPerPage;
      const indexOfFirstItem = indexOfLastItem - itemsPerPage;
      const currentItems = billingHistoryData.slice(indexOfFirstItem, indexOfLastItem);
    
      const paginate = (pageNumber) => {
        console.log("Page number clicked:", pageNumber);
    
        setCurrentPage(pageNumber);
      };
    
      const [showDetail, setShowDetail] = useState(false);
      const [selectedUserIndex, setSelectedUserIndex] = useState(null); 

  return (
    
    <div className='user_billing'>
    <div className="container back_img">
     
   
  </div>
   
    <div className='container'>
    <div className='check_bil'>
      <div className='billing_history pl-3 pt-3 pb-3'>
      <Link to='/adminpanel'>
      <button className='back_btn'>Back</button>
      </Link>
          
  
      </div>
      <table className="table table-striped bil_tab mb-1">
        <thead className='text-white tab_head'>
          <tr className='userdata_Tab'>
            <th className='pl-3'>Date</th>
            <th>Time</th>
            <th>Card Number</th>
            <th>Amount</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
{currentItems.map((record, index) => (
<tr className='' key={index} style={{ backgroundColor: index % 2 === 0 ? '#EDEDED' : '#DEDEDE' }}>
<td className='pl-3 '>{record.date}</td>
<td className=''>{record.time}</td>
<td className=''><span className='pr-2'><img src={card} alt='card'/></span>{record.cardNumber}</td>
<td className=''>{record.amount}</td>
<td className='text-white '>
<span className={`status_text3 ${record.status.toLowerCase()}`}>
      {record.status}
    </span>
</td>
</tr>
))}
</tbody>

      
      
      </table>
      <div className="pagination pb-2">
{Array.from({ length: Math.ceil(billingHistoryData.length / itemsPerPage) }, (_, index) => (
  <button key={index} className={`pagination-button ${currentPage === index + 1 ? 'active' : ''} btn_paginate`} onClick={() => paginate(index + 1)}>
    {index + 1}
  </button>
))}
</div>
    </div>
  </div>
  </div>
  )
}

export default BillingHistoryUserTable
