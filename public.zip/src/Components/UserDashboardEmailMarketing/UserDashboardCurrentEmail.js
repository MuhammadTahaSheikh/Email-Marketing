import React, { useState } from "react";
import "../UserDashboardEmailMarketing/UserDashboardCurrentEmail.css";
import calender from "../../Assets/calender.png";
import paynow from "../../Assets/paynow.png";
import received_link from "../../Assets/received_link.png";
import sent_link from "../../Assets/sent_link.png";
import { useLocation } from "react-router-dom";


function UserDashboardCurrentEmail() {
                         
  const location =useLocation();
  const amount = location.state?.name1.amount || 250;
 
  const sent_email = location.state?.name1.sentemail || 0;
  const received_email = location.state?.name1.receivedemail || 0;
  const [isSentBoxVisible, setIsSentBoxVisible] = useState(true);
  const [isSentBoxVisible_rec, setisSentBoxVisible_rec] = useState(true);

  
  const getColor_sent = (amount) => {                                                          
    if (amount) {
      return "background: linear-gradient(90deg, #018AD7 0%, #45BCFF 100%)";
    } 
  }
  const getColor_received = (amount) => {
    if (amount) {   
      return "#00B876";
    }
  };
  const color = getColor_sent(sent_email);               
                
  const boxSize = sent_email >= 270 ? 270 : sent_email;

  const color_received = getColor_received(received_email);

  const boxSize_received = received_email >= 270 ? 270 : received_email;
  const toggleSentBoxVisibility = () => {
    setIsSentBoxVisible(!isSentBoxVisible);    
  };
  const toggleSentBoxVisibility_rec = () => {
    setisSentBoxVisible_rec(!isSentBoxVisible_rec);
  };  
  return (
    <div className="user_main_two">
      <div className="container pt-5 pb-5">
        <div className="row displayy">
          <div className="col-sm-12 col-md-10 col-lg-6">
         <div className="userDashOne">
         
            <div className="row">
              <div className="col-8 dashone">
                <img src={calender} alt="calender" />
                <div className="userdashContent">
                  <div className={`text-white dueDate ${color}`}>
                    Due Date: 20 July, 2023
                  </div>
                  <div className="text-white">
                    <h4 className="paym">Due Payment</h4>
                  </div>
                  <div className="text-white">
                    <h1>${amount}</h1>
                  </div>
                </div>
              </div>
              <div className="col-4 dashtwo">
                <div className="userContent">
                  <img src={paynow} alt="pay_now" />
                  <span>Pay Now</span>
                </div>
              </div>
            </div>
         
           
          </div>    
          </div>                 
          <div className="col-sm-12 col-md-10 col-lg-6">
          <div className="userDashtwo">
            <div className="row">
              <div className="col-6">
                <p className="container-fluid month_detail">
                  Current Month Emails Stats
                </p>
                <p className="container-fluid month">DECEMBER</p>
                <div className="container">
                  <span onClick={toggleSentBoxVisibility} className="curs1">
                    <img src={sent_link} alt="sent_link" className="pr-2 sent_li" />
                    Sent
                  </span>
                  <span onClick={toggleSentBoxVisibility_rec} className="curs1">
                    <img
                      src={received_link}
                      alt="received_link"
                      className="rec pr-2 sent_li"
                    />
                    Received
                  </span>
                </div>
              </div>
              <div className="col-1 mt-3">
                <div className="straight-line1"></div>
              </div>
              
              <div className="col-5 state_value">
                <div>
                  <div className="color-box1-container">
                    {isSentBoxVisible && (
                      <div
                        className="color-box1"
                        style={{
                          width: `${boxSize}px`,
                          height: "20px",
                          backgroundColor: color,
                        }}
                      >
                        <div className="color-box1-label">{sent_email}</div>
                      </div>
                    )}
                    <br />
                    {isSentBoxVisible_rec && (
                      <div
                        className="color-box1"
                        style={{
                          width: `${boxSize_received}px`,
                          height: "20px",
                          backgroundColor: color_received,
                        }}
                      >
                        <div className="color-box1-label">{received_email}</div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
         
        </div>
        </div>
      </div>
    </div>
  );
}

export default UserDashboardCurrentEmail;
