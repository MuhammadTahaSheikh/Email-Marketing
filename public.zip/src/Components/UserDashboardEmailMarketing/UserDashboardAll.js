import React from 'react'

import UserDashboardCurrentEmail from '../UserDashboardEmailMarketing/UserDashboardCurrentEmail'
import UserDashboardMon_yearEmail from '../UserDashboardEmailMarketing/UserDashboardMon_yearEmail'
import UserDashboard from '../UserDashboardEmailMarketing/UserDashboard'
import UserDashboardBilling from '../UserDashboardEmailMarketing/UserDashboardBilling'
function UserDashboardAll() {
  
  return (
    <div>
    {/* */}
    <UserDashboard/>
    <UserDashboardCurrentEmail/>
    <UserDashboardMon_yearEmail/>
    <UserDashboardBilling/>
 
    </div>
  )
}

export default UserDashboardAll
