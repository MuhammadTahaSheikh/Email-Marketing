import React, { useState } from 'react';
import "../UserDashboardEmailMarketing/UserDashboardBilling.css";
import edit_btn from "../../Assets/btn_edit.png";
import card from "../../Assets/card.png";
import master from "../../Assets/masterCard.png";
import visa from "../../Assets/VisaCard.png";
function UserDashboardBilling() {
  const billingHistoryData = [
    { date: 'Nov 03, 2023', time: '06:50 PM', cardNumber: '**** 4231', amount: '$153.00', status: 'Paid' },
    { date: 'Nov 05, 2023', time: '07:50 PM', cardNumber: '**** 1453', amount: '$173.00', status: 'Denied' },
    { date: 'Dec 03, 2023', time: '08:50 PM', cardNumber: '**** 4231', amount: '$153.00', status: 'Paid' },
    { date: 'Jan 03, 2023', time: '09:50 PM', cardNumber: '**** 1453', amount: '$183.00', status: 'Pending' },
    { date: 'Nov 03, 2023', time: '06:50 PM', cardNumber: '**** 4231', amount: '$153.00', status: 'Paid' },
    { date: 'Nov 05, 2023', time: '07:50 PM', cardNumber: '**** 1453', amount: '$173.00', status: 'Denied' },
    { date: 'Dec 03, 2023', time: '08:50 PM', cardNumber: '**** 4231', amount: '$153.00', status: 'Paid' },
    { date: 'Jan 03, 2023', time: '09:50 PM', cardNumber: '**** 1453', amount: '$183.00', status: 'Pending' },
    { date: 'Nov 03, 2023', time: '06:50 PM', cardNumber: '**** 4231', amount: '$153.00', status: 'Paid' },
    { date: 'Nov 05, 2023', time: '07:50 PM', cardNumber: '**** 1453', amount: '$173.00', status: 'Denied' },
    { date: 'Dec 03, 2023', time: '08:50 PM', cardNumber: '**** 4231', amount: '$153.00', status: 'Paid' },
    { date: 'Jan 03, 2023', time: '09:50 PM', cardNumber: '**** 1453', amount: '$183.00', status: 'Pending' },
    { date: 'Nov 03, 2023', time: '06:50 PM', cardNumber: '**** 4231', amount: '$153.00', status: 'Paid' },
    { date: 'Nov 05, 2023', time: '07:50 PM', cardNumber: '**** 1453', amount: '$173.00', status: 'Denied' },
    { date: 'Dec 03, 2023', time: '08:50 PM', cardNumber: '**** 4231', amount: '$153.00', status: 'Paid' },
    { date: 'Jan 03, 2023', time: '09:50 PM', cardNumber: '**** 1453', amount: '$183.00', status: 'Pending' }
  ];
  const itemsPerPage = 8; // Number of items per page
  const [currentPage, setCurrentPage] = useState(1);
  
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentItems = billingHistoryData.slice(indexOfFirstItem, indexOfLastItem);

  const paginate = (pageNumber) => {
    console.log("Page number clicked:", pageNumber);

    setCurrentPage(pageNumber);
  };

  return (
    <div className='user_billing pb-5'>
      <div className='container'>
        <div className='row all_sec'>
        <div className='col-4'>
        <div className='billing_oneComp1'>
          <div className='row'>
            <div className='col-8 pl-5 pt-3 paym_all'>
              <span className='payment_met'>Payment Method</span>
            </div>
            <div className='col-4 pl-5 pt-3'>
              <a href="" className="link-success edit_btn"><img src={edit_btn} className='pr-1' alt="Edit"/>Edit</a>
            </div>
          </div>
          <div className='mt-5'>
            <div className='m-1'>
              <img className='master' src={master} alt="Mastercard"/>
            </div>
            <div className='m-1'>
              <img className='visa' src={visa} alt="Visa"/>
            </div>
            <div className='m-1'>
            <img className='visa' src={visa} alt="Visa"/>
          </div>
          </div>
                                 
            
          <div className="text-center mt-3">
            <button className="btn_payment text-white ml-3 mr-3">Update payment method</button>
          </div>
        </div> 
      </div>
           
       
          <div className='col-8'>
            <div className='billing_oneComp'>
              <div className='billing_history pl-3 pt-3 pb-3'>
                Billing History
              </div>
              <table className="table table-striped mb-1 custom-table">
              
                <thead className='text-white tab_hea'>
                  <tr className='head_conten'>
                    <th className='pl-3'>Date</th>
                    <th>Time</th>    
                    <th>Card Number</th>
                    <th>Amount</th> 
                    <th>Status</th> 
                  </tr>
                </thead>      
                  
                <tbody>
  {currentItems.map((record, index) => (
    <tr 
       
  >
                             
      <td className='pl-3 content_css'>{record.date}</td>
      <td className='content_css'>{record.time}</td>
      <td className='content_css'><span className='pr-2'><img src={card} alt='card'/></span>{record.cardNumber}</td>
      <td className='content_css'>{record.amount}</td>
      <td className='text-white content_css'>
      <span className={`status_text1 ${record.status.toLowerCase()}`}>
      {record.status}
    </span>                          
      </td>                 
    </tr>
  ))} 
</tbody>

              
              
              </table>
              <div className="pagination pb-2">
        {Array.from({ length: Math.ceil(billingHistoryData.length / itemsPerPage) }, (_, index) => (
          <button key={index} className={`pagination-button ${currentPage === index + 1 ? 'active' : ''} btn_paginate`} onClick={() => paginate(index + 1)}>
            {index + 1}
          </button>
        ))}
      </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default UserDashboardBilling;
