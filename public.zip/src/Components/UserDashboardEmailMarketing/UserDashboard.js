import React from 'react';
import '../UserDashboardEmailMarketing/UserDashboard.css';
import signout from "../../Assets/signout.png";
import img from "../../Assets/test_img.png";
import edit_btn from "../../Assets/Edit_Button.png"
import { Link } from "react-router-dom"; // Import necessary components from react-router-dom
import { useLocation } from 'react-router-dom';
function UserDashboard() {
  
  const location = useLocation();

  const userName = location.state?.name1.name || "Taha";
  const image = location.state?.name1.image || {img}
                 
                            
  return (
 
     <div className='user_main'>
    <div className="container ud_back">

      {/* Your content here */}
      <div className="flex-container">
        <div className="flex-grow"></div>                   
        {/* User profile link */}
        <div className="profile-info">
                                     
            <img src={image} alt="User Profile" className='user_profile' />
            
        
        </div>
        <div className='profile_content'>
        <span className="text-white ml-3">{userName}</span>
        <a href="/editProfile" className="text-white d-block ml-3 edit"><span><img src={edit_btn} alt='edit_btn'/></span>Edit Profile</a>
        </div>
        {/* Edit profile link */}
        
        {/* Straight line */}
        <div className="straight-line"></div>
        {/* Signout button */}
        <Link
        to="/"
        
      
      >  
        <button className="signout-button text-white"> <span className="signout"><img src={signout} alt="Signout" /></span>Log Out</button>
        </Link>
      </div>
    </div>
    </div>
  );
}

export default UserDashboard;
