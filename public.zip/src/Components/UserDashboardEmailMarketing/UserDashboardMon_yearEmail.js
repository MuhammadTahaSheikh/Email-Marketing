import React, { useState, useEffect, useRef } from "react";
import "../UserDashboardEmailMarketing/UserDashboardMon_yearEmail.css";
import received_link from "../../Assets/received_link.png";
import sent_link from "../../Assets/sent_link.png";
import {Chart, registerables, LineController, LineElement, PointElement, LinearScale, Title,} from "chart.js";
import { useLocation } from "react-router-dom";
function UserDashboardMon_yearEmail() {
  const location = useLocation();
  const val = location.state?.name1.value;
  const chartRef = useRef(null);
  Chart.register(LineController, LineElement, PointElement, LinearScale, Title);

  Chart.register(...registerables);
  useEffect(() => {
    if (chartRef.current) {
      chartRef.current.destroy();
    }                    
    

    const ctx = document.getElementById("myChart").getContext("2d");
console.log(val)
    const newChart = new Chart(ctx, {
      type: "bar",
      data: {
        labels: [
          "JAN",
          "FEB",
          "MAR",
          "APR",
          "MAY",
          "JUNE",
          "JLY",
          "AUG",
          "SEP",
          "OCT",
          "NOV",
          "DEC",
        ],
        datasets: [
          {
            label: "Sent",
            data: [40, 60, 120, 40, 60, 80, 20, 60, 120, 30, 70, 65],
            backgroundColor: "#018AD7",
            borderColor: "transparent",
            borderWidth: 2.5,
            barPercentage: 1,
          },
          {
            label: "Received",

            startAngle: 2,
            data: [20, 40, 20, 50, 25, 40, 25, 10, 90, 200, 100, 50],
            backgroundColor: "#00B876",
            borderColor: "transparent",
            borderWidth: 2.5,
            barPercentage: 1,
          },
        ],
      },
      options: {
        scales: {
          yAxes: [   
            {
              gridLines: {},
              
              ticks: {
                stepSize: 15,
              },
            },
          ],
          xAxes: [
            {
              gridLines: {
                display: false,
              },
            },
          ],
        },
      },
    });
    chartRef.current = newChart;
         
    return () => {
      newChart.destroy();  
    };
  }, []);

  // Calculate the size of the color box based on the due payment value

  const [dataRows, setDataRows] = useState([
    {
      id: 1,
      header: "1",
      sent_email: "110",
      received_email: "0",
      email: "taha@360synergytech.com",
    },
    {
      id: 2,
      header: "2",
      sent_email: "612",
      received_email: "100",
      email: "ahmed.farooq@360synergytech.com",
    },
    {
      id: 3,
      header: "3",
      sent_email: "312",
      received_email: "1",
      email: "moughees@360synergytech.com",
    },
    {
      id: 4,
      header: "4",
      sent_email: "2",
      received_email: "1",
      email: "taha@360synergytech.com",
    },
    {
      id: 5,
      header: "5",
      sent_email: "1",
      received_email: "1",
      email: "taha@360synergytech.com",
    },
    {
      id: 6,
      header: "6",
      sent_email: "2",
      received_email: "1",
      email: "taha@360synergytech.com",
    },
    {
      id: 7,
      header: "7",
      sent_email: "1",
      received_email: "1",
      email: "taha@360synergytech.com",
    },
    {
      id: 8,
      header: "8",  
      sent_email: "30",
      received_email: "1",
      email: "taha@360synergytech.com",
    },
    
  ]);
  
             
  return (
    <div className="user_main"> 
      <div className="container pb-5">
        <div className="row">
          <div className="col-xl-8 col-lg-7 col-md-12 col-sm-12 col-12">
            <div className="inner_width comp_one">
              <div className="wrapper">
                <div className="chart-wrapper">       
                  <div className="progress-wrapper">
                    <p className="pt-2 pl-2 graph_data">
                      Monthly/Yearly Emails     
                    </p>
                    <canvas id="myChart" className="chartcss"></canvas>
                  </div>
                </div>        
              </div>    
            </div>
          </div>
          
          <div className=" col-xl-4 col-lg-5 col-md-7 col-sm-9 col-12 comp_two">
            <div className="mt-3 mb-3">   
              <span className="sec_two">Individual Emails</span>
              <span className="curs">     
                <img src={sent_link} alt="sent_link" className="pr-2" />
                Sent
              </span>           
              <span className="curs">             
                <img
                  src={received_link}
                  alt="received_link"
                  className="rec pr-2"   
                />
                Received    
              </span> 
            </div>
            <div className="table-container basicPackagesUL">
              <table>
                <tbody>
                  {dataRows.map((row) => (
                    <tr key={row.id} className="tr_table">
                        <th className="row_number">{row.header}</th>

                      <div className="tab_data">
                        <td className="tab_data td_email pb-2">{row.email}</td>

                        <td> 
                          <div
                            className="color-box"
                            style={{
                              width: `${Math.max(20, Math.min(row.sent_email, 300))}px`,
                              height: "20px",
                              backgroundColor: "#018AD7",
                             
                            }}        
                                         
                          >
                         
                            <div className="color-box-label">
                              {row.sent_email}
                            </div>
                          </div>

                          <div className="space"></div>

                          <div
                            className="color-box"
                            style={{
                              width: `${Math.max(20,Math.min(row.received_email,300))}px`,
                             
                              height: "20px",
                              backgroundColor: "#00B876",
                            }}
                          >
                            <div className="color-box-label">
                              {row.received_email}
                            </div>
                          </div>
                        </td>
                      </div>
                    </tr>
                  ))}          
                  <div className="col-5 state_value"></div>     
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default UserDashboardMon_yearEmail;
