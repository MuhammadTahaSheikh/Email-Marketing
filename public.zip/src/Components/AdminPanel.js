import React from 'react'
import AdminPanelMain from './AdminPanelEmailMarketing/AdminPanelMain'
import AdminPanelRecord from './AdminPanelEmailMarketing/AdminPanelRecord'
import AdminPanelUsertable from './AdminPanelEmailMarketing/AdminPanelUsertable'

function AdminPanel() {
  return (
    <div>
      <AdminPanelMain/>
      <AdminPanelRecord/>
      <AdminPanelUsertable/>
    </div>
  )
}

export default AdminPanel
