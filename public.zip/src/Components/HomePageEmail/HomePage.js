import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
// ... other imports
import "../HomePageEmail/HomePage.css"
import HeadingEmail from '../HeadingEmailMarketing/HeadingEmail.js'
import NavbarEmail from '../Navbar/NavbarEmail'
import PackagesEmail from '../Packages/PackagesEmail'
import TestimonialsEmail from '../Testimonials/TestimonialsEmail'
import FaqEmail from '../FaqEmailMarketing/FaqEmail'
import FooterEmail from '../FooterEmailMarketing/FooterEmail'
import UserDashboardCurrentEmail from '../UserDashboardEmailMarketing/UserDashboardCurrentEmail'
import UserDashboardMon_yearEmail from '../UserDashboardEmailMarketing/UserDashboardMon_yearEmail'
import UserDashboard from '../UserDashboardEmailMarketing/UserDashboard'
import UserDashboardBilling from '../UserDashboardEmailMarketing/UserDashboardBilling'
import AdminPanelMain from "../AdminPanelEmailMarketing/AdminPanelMain"
import AdminPanelRecord from "../AdminPanelEmailMarketing/AdminPanelRecord"
import AdminPanelUsertable from "../AdminPanelEmailMarketing/AdminPanelUsertable"
import BillingHistoryNav from "../BillingEmailMarketing/BillingHistoryNav"
import BillingHistoryRecord from "../BillingEmailMarketing/BillingHistoryRecord"
import BillingHistoryUserTable from "../BillingEmailMarketing/BillingHistoryUserTable"
function HomePage() {
  return (
    <div>

    <NavbarEmail />
    <HeadingEmail />
     <div id='packages'><PackagesEmail /></div>
      <div id='reviews'><TestimonialsEmail /></div>
    <FaqEmail />
    <FooterEmail />
         
        
          
          {/* ... other routes */}
        
      {/*
        <NavbarEmail />
      <HeadingEmail />
       <div id='packages'><PackagesEmail /></div>
        <div id='reviews'><TestimonialsEmail /></div>
      <FaqEmail />
      <FooterEmail />
     <NavbarEmail />
        <HeadingEmail />
        <div id='packages'><PackagesEmail /></div>
        <div id='reviews'><TestimonialsEmail /></div>
        <FaqEmail />
        <FooterEmail />
          <TestimonialsEmail/>
        <AdminPanelMain />
       
        <AdminPanelUsertable />
   */}
    </div>
  );
}

export default HomePage;
