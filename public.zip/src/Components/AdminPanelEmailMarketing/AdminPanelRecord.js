import React from 'react'
import "../AdminPanelEmailMarketing/AdminPanelRecord.css"
function AdminPanelRecord() {
  return (
    <div className='record_main'>
    <div className='container pt-5 pb-5'>
    <div className='row'>
    <div className='col-lg-9 col-md-8 col-7'>
    <h2 className='ad_paneladm'>ADMIN PANEL</h2>
    </div>
    <div className='col-lg-3 col-md-4 col-5'>
    <div><span className='users_contadm'>Total Users:</span><span className='users_amt'>2000</span></div>
    <div><span className='users_contadm'>Active Users:</span><span className='users_amt'>2000</span></div>
    
    </div>
    </div>
    </div>
    </div>
  )
}

export default AdminPanelRecord
