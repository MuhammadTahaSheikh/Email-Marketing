import React from 'react';
import '../UserDashboardEmailMarketing/UserDashboard.css';
import signout from "../../Assets/signout.png";
import img from "../../Assets/test_img.png";
import edit_btn from "../../Assets/Edit_Button.png"
import "../AdminPanelEmailMarketing/AdminPanelMain.css"
import { Link, Route, Switch, useLocation } from "react-router-dom"; // Import necessary components from react-router-dom

function AdminPanelMain() {
  const location =useLocation();
  const name = location.state?.name1.name || "taha";
  return (
    
    <div className='user_main_admin'>
    <div className="container back_img">
     
      <div className="flex-container">
        <div className="flex-grow"></div> 
      
        <div className="profile-info">
        
            <img src={img} alt="User Profile" className='user_profile_admin' />
          
        
        </div>
        <div className='name_head'>
        <span className="text-white ml-3">{name}</span>
        <a href="/editProfile" className="text-white d-block ml-3 edit_btn"><span><img src={edit_btn}/></span>Edit Profile</a>
        </div>
 
        
   
        <div className="straight-line_nav"></div>
        {/* Signout button */}
        <Link
        to="/"
        
      
      >    <button className="signout-button_adm text-white"> <span className="signout"><img src={signout} alt="Signout" /></span>
       
     Log Out</button> </Link>
      </div>
    </div>

z
    </div>
  
  )
}

export default AdminPanelMain
