import React, { useState, useEffect } from "react";
import { BrowserRouter as Router, Route, Link, Switch } from 'react-router-dom';

import BillingHistoryUserTable from "../BillingEmailMarketing/BillingHistoryUserTable";
import "../AdminPanelEmailMarketing/AdminPanelUsertable.css";
import toogle_on from "../../Assets/toggle_on.png";
import toogle_off from "../../Assets/toggle_off.png";
import delete_img from "../../Assets/delete.png";

import edit from "../../Assets/edit.png";

function AdminPanelUsertable() {
 

  const [isDetailOpen, setIsDetailOpen] = useState(false);

  const [AdminUsers, setAdminUsers] = useState([
    {
      img: ``,
      name: "Taha",
      email: "tahasheikh@gmail.com",
      activation: "",
      status: "Active",
      remarks: "All payments clear.",
      operations: "",
      billingHistory: "Details",
    },
    {
      img: "",
      name: "Ahmed",
      email: "tahasheikh@gmail.com",
      activation: "",
      status: "inactive",
      remarks: "Outstanding dues.",
      operations: "",
      billingHistory: "Details",
    },
    {
      img: "",
      name: "Taha",
      email: "tahasheikh@gmail.com",
      activation: "",
      status: "Active",
      remarks: "All payments clear.",
      operations: "",
      billingHistory: "Details",
    },
    {
      img: "",
      name: "Taha",
      email: "tahasheikh@gmail.com",
      activation: "",
      status: "inactive",
      remarks: "Outstanding dues.",
      operations: "",
      billingHistory: "Details",
    },
    {
      img: "",
      name: "Taha",
      email: "tahasheikh@gmail.com",
      activation: "",
      status: "inactive",
      remarks: "Outstanding dues.",
      operations: "",
      billingHistory: "Details",
    },
    {
      img: "",
      name: "Taha",
      email: "tahasheikh@gmail.com",
      activation: "",
      status: "Active",
      remarks: "All payments clear.",
      operations: "",
      billingHistory: "Details",
    },
    {
      img: "",
      name: "Taha",
      email: "tahasheikh@gmail.com",
      activation: "",
      status: "Active",
      remarks: "All payments clear.",
      operations: "",
      billingHistory: "Details",
    },
    {
      img: "",
      name: "Taha",
      email: "tahasheikh@gmail.com",
      activation: "",
      status: "inactive",
      remarks: "Outstanding dues.",
      operations: "",
      billingHistory: "Details",
    },
    {
      img: "",
      name: "Taha",
      email: "tahasheikh@gmail.com",
      activation: "",
      status: "Active",
      remarks: "All payments clear.",
      operations: "",
      billingHistory: "Details",
    },
    {
      img: "",
      name: "Taha",
      email: "tahasheikh@gmail.com",
      activation: "",
      status: "inactive",
      remarks: "Outstanding dues.",
      operations: "",
      billingHistory: "Details",
    },
    {
      img: "",
      name: "Taha",
      email: "tahasheikh@gmail.com",
      activation: "",
      status: "inactive",
      remarks: "Outstanding dues.",
      operations: "",
      billingHistory: "Details",
    },
    {
      img: "",
      name: "Taha",
      email: "tahasheikh@gmail.com",
      activation: "",
      status: "Active",
      remarks: "All payments clear.",
      operations: "",
      billingHistory: "Details",
    },
    {
      img: "",
      name: "Taha",
      email: "tahasheikh@gmail.com",
      activation: "",
      status: "Active",
      remarks: "All payments clear.",
      operations: "",
      billingHistory: "Details",
    },
    {
      img: "",
      name: "Taha",
      email: "tahasheikh@gmail.com",
      activation: "",
      status: "inactive",
      remarks: "Outstanding dues.",
      operations: "",
      billingHistory: "Details",
    },
    {
      img: "",
      name: "Taha",
      email: "tahasheikh@gmail.com",
      activation: "",
      status: "Active",
      remarks: "All payments clear.",
      operations: "",
      billingHistory: "Details",
    },
    {
      img: "",
      name: "Taha",
      email: "tahasheikh@gmail.com",
      activation: "",
      status: "inactive",
      remarks: "Outstanding dues.",
      operations: "",
      billingHistory: "Details",
    },
    {
      img: "",
      name: "Taha",
      email: "tahasheikh@gmail.com",
      activation: "",
      status: "inactive",
      remarks: "Outstanding dues.",
      operations: "",
      billingHistory: "Details",
    },
    {
      img: "",
      name: "Taha",
      email: "tahasheikh@gmail.com",
      activation: "",
      status: "Active",
      remarks: "All payments clear.",
      operations: "",
      billingHistory: "Details",
    },
  ]);

  const handleDelete = (index) => {
    const confirmDelete = window.confirm("Are you sure you want to delete this user?");
    if (confirmDelete) {
      setAdminUsers((prevAdminUsers) => {
        const newAdminUsers = [...prevAdminUsers];
        newAdminUsers.splice(index, 1);
        return newAdminUsers;
      });
    }
  };
  
  const [editableFields, setEditableFields] = useState({});

  const itemPerPage = 10;
  const [currentPage, setcurrentPage] = useState(1);
  const indexOfLastItem = currentPage * itemPerPage;
  const indexofFirstItem = indexOfLastItem - itemPerPage;
  const currentItems = AdminUsers.slice(indexofFirstItem, indexOfLastItem);
  const paginate = (pageNumber) => {
    setcurrentPage(pageNumber);
  };
  const [activationStatus, setActivationStatus] = useState({});
  useEffect(() => {
    // Initialize activationStatus array with default values
    setActivationStatus(Array(AdminUsers.length).fill(true));
  }, [AdminUsers.length]);

  const handleToggle = (itemIndexOnPage) => {
    const realIndex = indexofFirstItem + itemIndexOnPage;

    setActivationStatus((prevState) => {
      const newActivationStatus = [...prevState];
      newActivationStatus[realIndex] = !newActivationStatus[realIndex];

      // Update status and remarks based on activation status
      setAdminUsers((prevAdminUsers) => {
        const newAdminUsers = [...prevAdminUsers];
        if (newActivationStatus[realIndex]) {
          newAdminUsers[realIndex].status = "Active";
          newAdminUsers[realIndex].remarks = "All payments clear.";
        } else {
          newAdminUsers[realIndex].status = "Inactive";
          newAdminUsers[realIndex].remarks = "Outstanding dues.";
        }
        return newAdminUsers;
      });

      return newActivationStatus;
    });
  };
  const handleEdit = (index) => {
    setEditableFields((prevEditableFields) => ({
      ...prevEditableFields,
      [index]: {
        name: AdminUsers[index].name,
        email: AdminUsers[index].email,
      },
    }));
  };
  
  const handleEditChange = (index, field, value) => {
    setEditableFields((prevEditableFields) => ({
      ...prevEditableFields,
      [index]: {
        ...prevEditableFields[index],
        [field]: value,
      },
    }));
  };
  
  const handleSaveEdit = (index) => {
    setAdminUsers((prevAdminUsers) => {
      const newAdminUsers = [...prevAdminUsers];
      newAdminUsers[index].name = editableFields[index].name;
      newAdminUsers[index].email = editableFields[index].email;
      return newAdminUsers;
    });
    // Remove the editable field state for this row
    setEditableFields((prevEditableFields) => {
      const newEditableFields = { ...prevEditableFields };
      delete newEditableFields[index];
      return newEditableFields;
    });
  };
  
  const handleCancelEdit = (index) => {
    // Remove the editable field state for this row
    setEditableFields((prevEditableFields) => {
      const newEditableFields = { ...prevEditableFields };
      delete newEditableFields[index];
      return newEditableFields;
    });
    
  };

  const [showDetail, setShowDetail] = useState(false);
  const [selectedUserIndex, setSelectedUserIndex] = useState(null); // Track the selected user's index

  const handleLinkClick = (index) => {
    setShowDetail(true); 
    setSelectedUserIndex(index); 
  };      
         
  return (
      <div>
      
        
  
    <div className="usertable_main">
  
      <div className="container">
    
        
        <div className="user_table">
        
          <div className="main_filter">
            <h2 className="user_css pl-3 pt-3">Users</h2>
            <div className="filters pt-3 pb-3">
              <select className="filter-dropdown mr-3">
                <option value="all">December</option>
                {/* Add options for each month */}
              </select>
              <select className="filter-dropdown mr-3">
                <option value="all">2022</option>
                {/* Add options for each year */} 
              </select>
              <select className="filter-dropdown mr-3">
                <option value="all">Filter</option>
                <option value="active">Active</option>
                <option value="inactive">Inactive</option>
              </select>
   
              <input
                type="text"
                placeholder="Search..."
                className="search-input mr-3"
              />
            </div>
          </div>

          <div className="table-container1" style={{ overflowX: "auto" }}>
                 
            <table className="table table-striped mb-1 adm_tab">
              <thead className="text-white tab_headAdm">
                <tr className="head_content">
                  <th className="pl-3"></th>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Activation</th>
                  <th>Status</th>
                  <th>Remarks</th>
                  <th>Operations</th>
                  <th>Billing History</th>
                </tr>
              </thead>
              <tbody>
                {currentItems.map((record, index) => (
                  <tr key={index}>


                    <td className="pl-3 contentAdm_css">
                      {record.img ? (
                        <img src={record.img} alt="User" className="user-img" />
                      ) : (
                        <span>No Image</span>
                      )}
                    </td>

       

                    <td className="contentAdm_css">
                      {editableFields[index] ? (
                        <input
                          type="text"
                          value={editableFields[index].name}
                          onChange={(e) =>
                            handleEditChange(index, "name", e.target.value)
                          }
                        />
                      ) : (
                        record.name
                      )}
                    </td>





                    <td className="contentAdm_css">
                      {editableFields[index] ? (
                        <input
                          type="email"
                          value={editableFields[index].email}
                          onChange={(e) =>
                            handleEditChange(index, "email", e.target.value)
                          }
                        />
                      ) : (
                        record.email
                      )}
                    </td>







                    <td className="contentAdm_css">
                      <button
                        className={`toggle-button ${
                          record.status === "Active" ? "on" : "off"
                        }`}
                        onClick={() => handleToggle(index)}
                      >
                        {record.status === "Active" ? (
                          <img src={toogle_on} alt="Toggle On" className="toogle_btn" />
                        ) : (
                          <img src={toogle_off} alt="Toggle Off" className="toogle_btn" />
                        )}
                      </button>
                    </td>









                    <td className="text-white contentAdm_css">
                      <span
                        className={`status_textAdm1 ${
                          record.status === "Active" ? "activee" : "inactive"
                        }`}
                      >
                        {record.status}
                      </span>
                    </td>







                    <td className="contentAdm_css">{record.remarks}</td>

                    <td className="contentAdm_css_btn">
                    <div>
                      {editableFields[index] ? (
                        <>   
                          <button className="editButton" onClick={() => handleSaveEdit(index)}>
                            Save   
                          </button>   
                          <button className="editButton" onClick={() => handleCancelEdit(index)}>
                            Cancel   
                          </button>  
                        </>    
                      ) : (                                              
                        <>                                                                                                                               
                          <button className="editButton" onClick={() => handleEdit(index)}> 
                          <img src={edit} alt="Delete" />
                          </button>
                          <button className="deleteButton" onClick={() => handleDelete(index)}>
                            <img src={delete_img} alt="Delete" />
                          </button>
                        </>                                                                                                           
                      )}
                    </div>
                  </td>      
     
              <td className="contentAdm_css">
              <Link to='/billinghistory'>
                  <button className='detail_btn' onClick={() => handleLinkClick(index)}>
                    Details
                  </button>
                  </Link>
                </td>
                
    







                  </tr>
                ))}
              </tbody>
            </table>
            
            <div className="pagination pb-2">
              {Array.from(
                { length: Math.ceil(AdminUsers.length / itemPerPage) },
                (_, index) => (
                  <button
                    key={index}
                    className={`pagination-button ${
                      currentPage === index + 1 ? "active" : ""
                    } btn_paginate`}
                    onClick={() => paginate(index + 1)}
                  >
                    {index + 1}
                  </button>
                )
              )}
            </div>
          </div>
        </div>
      

       
        </div>
    </div>
   
   
    </div>
  );
}

export default AdminPanelUsertable;
