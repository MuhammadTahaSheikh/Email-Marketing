import React, { useState } from "react";
import { CircularProgress, TextField } from "@mui/material";
import { Link } from "react-router-dom";
import heading_image from "../../Assets/heading_image.png";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { IconButton } from "@mui/material";
import { Visibility, VisibilityOff } from "@mui/icons-material";

const ModalSignIn = ({ isOpen, onClose }) => {
  const [showPassword, setShowPassword] = useState(false);
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    email: "",
    password: "",
    role: "",
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleFormSubmit = async (event) => {
    event.preventDefault();
   
    setIsSubmitting(true);
    try {
      const response = await axios.post(
        "https://a7f6-139-135-32-3.ngrok-free.app/test/testfile1.php",
        formData,
        {
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
          },
        }
      );

      if (response.status === 200) {
      

        if (response.data.role === "admin") {

          setTimeout(() => {
            setIsSubmitting(false);
            navigate("/adminpanel", { state: { name1: response.data } });
          }, 2000);
        } else if (response.data.role === "user") {
          setTimeout(() => {
            setIsSubmitting(false);
            navigate("/userdashboard", { state: { name1: response.data } });
          }, 1000);
        }
      } else {
        setIsSubmitting(false);
      }
    } catch (error) {
      if (error.response) {
        // Display a message to the user
        alert("Error: Unable to fetch the requested resource.");
      } else if (error.request) {
        // alert('Error: No response received');
      } else {
        alert("Error: " + error.message);
      }
      setIsSubmitting(false);
    }
  };

  const handleInputChange = (event) => {
    const { id, value } = event.target;
    setFormData((prevData) => ({
      ...prevData,
      [id]: value,
    }));
  };
  if (!isOpen) return null;

  return (
    <div className="modal-overlay">
      <div className="modal1">
        <button className="close-button" onClick={onClose}>
          &times;
        </button>
        <div>
          <div className="container-fluid">
            <div className="row">
              <div className="col-xl-9 col-lg-9 col-md-8 col-sm-6 img_back_form">
                <img
                  src={heading_image}
                  alt="Heading"
                  className="image_headingsign"
                />
              </div>
              <div className="col-xl-3 col-lg-3 col-md-4 col-sm-6 form_back_col">
                <div>
                  <h1 className="signin_label pt-4 pb-5">Sign In</h1>
                </div>
                {isSubmitting && (
                  <div className="loader-container">
                    <CircularProgress size={50} />
                  </div>
                )}
                <form onSubmit={handleFormSubmit}>
                  <div className="form-group mb-4">
                    <TextField
                      id="email"
                      label="EMAIL ADDRESS"
                      variant="outlined"
                      fullWidth
                      InputLabelProps={{
                        className: "",
                      }}
                      required
                      type="email"
                      onChange={handleInputChange}
                      inputProps={{
                        pattern:
                          "[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}",
                        title: "Please enter a valid email address",
                      }}
                    />
                  </div>

                  <div className="form-group">
                    <TextField
                      id="password"
                      label="PASSWORD"
                      variant="outlined"
                      type={showPassword ? "text" : "password"}
                      fullWidth
                      InputLabelProps={{
                        className: "custom-label",
                      }}
                      required
                      onChange={handleInputChange}
                      InputProps={{
                        endAdornment: (
                          <IconButton
                            onClick={() => setShowPassword(!showPassword)}
                          >
                          {showPassword ? <Visibility/> : <VisibilityOff/>}
                          </IconButton>
                        ),
                      }}
                    />
                  </div>

                  <div className="form-group text-center pt-3 pb-3">
                    <Link to="/forgot-password">
                      {" "}
                      <a href="#forgot-password">Forgot Password?</a>
                    </Link>
                  </div>
                  <div className="container">
                    {" "}
                    <button
                      type="submit"
                      className="w-100 btn btn-light btn_form mb-3"
                    >
                      Sign In
                    </button>{" "}
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ModalSignIn;
