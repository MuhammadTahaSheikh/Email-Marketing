import React from 'react'
import "../SignInUp/ForgetPassword.css"
import heading_image from "../../Assets/heading_image.png";
import TextField from '@mui/material/TextField';
import { Link } from "react-router-dom"; // Import necessary components from react-router-dom

function ForgetPassword() {
  return (
    <div>
     <div className='container-fluid'>
     <div className='row'>
     <div className='col-xl-9 col-lg-9 col-md-8 col-sm-6  img_back_form'> 
     <img src={heading_image} alt="Heading" className='image_headingforget' />

     </div>
   
     <div className="col-xl-3 col-lg-3 col-md-4 col-sm-6 form_back_col">
     <div><h1 className='signin_label pt-4 pb-2'>Forget Password</h1></div>
     <div><h3 className='signin_label1 pt-4 pb-5'>Kindly enter your Email & We will send
     you a reset link</h3></div>  
     <form>
      
       <div className="form-group pb-3">
        
         <TextField
           id="email"
           label="EMAIL ADDRESS"
           variant="outlined"
           fullWidth
           InputLabelProps={{
             className: 'custom-label'          
           }}
            required
         />
       </div>
      
    
       <div className='container'> <button type="submit" className="w-100 btn btn-light btn_form">
       Send Email
     </button></div>
     <div className="form-group text-center pt-3 pb-3">
     <Link to="/"><a href="#I-know-my-password">I know my password</a></Link>
     
   </div>
     </form>
   </div>
   
  
     </div>
     </div>
    </div>
  )
}

export default ForgetPassword
