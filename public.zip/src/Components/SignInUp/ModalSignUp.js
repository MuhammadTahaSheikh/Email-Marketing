import React, { useState } from 'react';
import "../SignInUp/ModalSignUp.css";
import { CircularProgress } from '@mui/material';
import heading_image from "../../Assets/heading_image.png";
import TextField from '@mui/material/TextField';
import InputAdornment from '@mui/material/InputAdornment';
import IconButton from '@mui/material/IconButton';
import Visibility from '@mui/icons-material/Visibility';
import VisibilityOff from '@mui/icons-material/VisibilityOff';
import axios from 'axios';

const ModalSignUp = ({ isOpen, onClose }) => {
  const [errorMessage, setErrorMessage] = useState()
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    password_confirmation: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [registrationStatus, setRegistrationStatus] = useState(null);
  const [passwordError, setPasswordError] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const handleFormSubmit = async (event) => {
    event.preventDefault();
    if (formData.password !== formData.password_confirmation) {
      setPasswordError("Passwords do not match");
      return;
    }

    // Add password validation here
    const uppercaseRegex = /[A-Z]/;
    const lowercaseRegex = /[a-z]/;
    const specialCharRegex = /[!@#$%^&*(),.?":{}|<>]/;

    if (
      !uppercaseRegex.test(formData.password) ||
      !lowercaseRegex.test(formData.password) ||
      !specialCharRegex.test(formData.password)
    ) {
      setPasswordError(
        "Password must contain at least one uppercase letter, one lowercase letter, and one special character."
      );
      return;
    }
  
    setIsSubmitting(true);
    try {
      const response = await axios.post(
        'https://a7f6-139-135-32-3.ngrok-free.app/test/testfile.php',
        formData,
        {
          headers: {
            'Content-Type': 'application/jsonp'
          }
        }
      );

      if (response.status === 200) {
        const role = response.data.name;
        console.log(role);
        console.log("Successful");
        setRegistrationStatus('success');

        console.log("Response data:", response.data);

      } else {
        setRegistrationStatus('failed');
        setIsSubmitting(false);
      }
    } catch (error) {
      console.error('Error submitting form:', error);
      setRegistrationStatus('failed');
      setIsSubmitting(false);
      setErrorMessage('An error occurred (Server Error). Please try again later.');
    }
  };

  const handleInputChange = (event) => {
    const { id, value } = event.target;
    setFormData((prevData) => ({
      ...prevData,
      [id]: value
    }));
    if (id === 'password' || id === 'password_confirmation') {
      setPasswordError('');
    }
  };

  if (!isOpen) return null;

  return (
    <div className="modal-overlay">
      <div className="modal1">
        <button className="close-button" onClick={onClose}>
          &times;
        </button>
        <div className='container-fluid'>
          <div className='row'>
            <div className='col-xl-9 col-lg-8 col-md-7 col-sm-6 img_back_form'>
              <img src={heading_image} alt="Heading" className='image_headingsignup' />
            </div>
            <div className="col-xl-3 col-lg-4 col-md-5 col-sm-6 form_back_col">
              <div><h1 className='signin_label pt-4 pb-5'>Sign Up</h1></div>
              {registrationStatus === 'success' ? (
                <div className="registration-success-message text-bold text-center"><h3 className='text-center'>Verification is send to your email kindly check your Email for proceed</h3></div>
              ) : (
                <div>
                  {isSubmitting && (
                    <div className="loader-container">
                      <CircularProgress size={50} />
                    </div>
                  )}
                  {errorMessage && (
                    <div className='error-message text-bold text-center'>
                      <h3 className='text-center'>{errorMessage}</h3>
                    </div>
                  )}
                  <form onSubmit={handleFormSubmit}>
                    <div className="form-group pb-3">
                      <TextField
                        id="name"
                        label="FULL NAME"
                        variant="outlined"
                        fullWidth
                        InputLabelProps={{
                          className: 'custom-label'
                        }}
                        onChange={handleInputChange}
                      />
                    </div>
                    <div className="form-group pb-3">
                      <TextField
                        id="email"
                        label="EMAIL"
                        variant="outlined"
                        fullWidth
                        InputLabelProps={{
                          className: 'custom-label'
                        }}
                        onChange={handleInputChange}
                      />
                    </div>
                    <div className="form-group pb-3">
                      <TextField
                        id="password"
                        label="PASSWORD"
                        variant="outlined"
                        type={showPassword ? 'text' : 'password'}
                        fullWidth
                        InputLabelProps={{
                          className: 'custom-label'
                        }}
                        required
                        error={passwordError !== ''}
                        helperText={passwordError}
                        onChange={handleInputChange}
                        InputProps={{
                          endAdornment: (
                            <InputAdornment position="end">
                              <IconButton
                                onClick={() => setShowPassword(!showPassword)}
                                edge="end"
                              >
                                {showPassword ? <Visibility /> : <VisibilityOff />}
                              </IconButton>
                            </InputAdornment>
                          ),
                        }}
                      />
                    </div>
                    <div className="form-group">
                      <TextField
                        id="password_confirmation"
                        label="CONFIRM PASSWORD"
                        variant="outlined"
                        type={showConfirmPassword ? 'text' : 'password'}
                        fullWidth
                        InputLabelProps={{
                          className: 'custom-label'
                        }}
                        required
                        error={passwordError !== ''}
                        helperText={passwordError}
                        onChange={handleInputChange}
                        InputProps={{
                          endAdornment: (
                            <InputAdornment position="end">
                              <IconButton
                                onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                                edge="end"
                              >
                                {showConfirmPassword ? <Visibility /> : <VisibilityOff />}
                              </IconButton>
                            </InputAdornment>
                          ),
                        }}
                      />
                    </div>
                    <div className='container'>
                      <button type="submit" className="w-100 btn btn-light btn_form mb-3">
                        Sign Up
                      </button>
                    </div>
                  </form>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ModalSignUp;
