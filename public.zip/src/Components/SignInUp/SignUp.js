import React, { useState } from 'react';
import "../SignInUp/SignUp.css";
import { useNavigate } from 'react-router-dom';

import heading_image from "../../Assets/heading_image.png";
import TextField from '@mui/material/TextField';
import axios from 'axios';


function SignUp() {
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    password_confirmation: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [registrationStatus, setRegistrationStatus] = useState(null);

  const handleFormSubmit = async (event) => {
    event.preventDefault();
    setIsSubmitting(true);
    try {
      const response = await axios.post('https://d2b2-139-135-32-3.ngrok-free.app/test/testfile.php', formData, {
        headers: {
          'Content-Type': 'application/json'
        }
      });

      if (response.status === 200) {
        const role = response.data.name; 
        console.log(role);
        console.log("Successful")
        setRegistrationStatus('success');
       
        console.log("Response data:", response.data); 
        setTimeout(() => {
          setIsSubmitting(false); // Stop loading
          navigate('/');
        }, 2000); // Delay navigation for 2 seconds
      } else {
        setRegistrationStatus('failed');
        setIsSubmitting(false); // Stop loading
      }
    }catch (error) {
      console.error('Error submitting form:', error);
      setRegistrationStatus('failed');
      setIsSubmitting(false);
    }
  };

  const handleInputChange = (event) => {
    const { id, value } = event.target;
    setFormData((prevData) => ({
      ...prevData,
      [id]: value
    
    }));
     console.log(value);
  };
  return (
    <div>
     <div className='container-fluid'>
     <div className='row'>
     <div className='col-xl-9 col-lg-9 col-md-8 col-sm-6 img_back_form'> 
     <img src={heading_image} alt="Heading" className='image_headingsignup' />

     </div>
   
     <div className="col-xl-3 col-lg-3 col-md-4 col-sm-6 form_back_col">
     <div><h1 className='signin_label pt-4 pb-5'>Sign Up</h1></div>
     {registrationStatus === 'success' ? (
      <div className="registration-success-message text-bold text-center"><h3 className='text-center'>Registration successful!</h3></div>
    ) : (
   
      <form onSubmit={handleFormSubmit}>
       <div className="form-group pb-3">
        
         <TextField
           id="name"
           label="FULL NAME"
           variant="outlined"
           fullWidth
           InputLabelProps={{
             className: 'custom-label'
           }}
           onChange={handleInputChange}

         />
       </div>
       <div className="form-group pb-3">
        
         <TextField
           id="email"
           label="EMAIL"
           variant="outlined"
           fullWidth
           InputLabelProps={{
             className: 'custom-label'
           }}
           onChange={handleInputChange}

         />
       </div>
      
       <div className="form-group pb-3">
        
         <TextField
           id="password"
           label="PASSWORD"
           variant="outlined"
           type="password"
           fullWidth
           InputLabelProps={{
             className: 'custom-label'
           }}
           required 
           onChange={handleInputChange}

         />
       </div>
          
       <div className="form-group">
        
         <TextField
           id="password_confirmation"
           label="CONFIRM PASSWORD"
           variant="outlined"
           type="password"
           fullWidth
           InputLabelProps={{
             className: 'custom-label'
           }}
           required 
           onChange={handleInputChange}

         />
       </div>
      
       <div className='container'> <button type="submit" className="w-100 btn btn-light btn_form">
       Sign Up
     </button></div>
    
     </form>
    
    )}
   </div>
   
  
     </div>
     </div>
    </div>
    
  )
}

export default SignUp
