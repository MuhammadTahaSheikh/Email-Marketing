import React from 'react'
import "../SignInUp/SignIn.css"
import { Link } from "react-router-dom"; // Import necessary components from react-router-dom
import heading_image from "../../Assets/heading_image.png";
import TextField from '@mui/material/TextField';
import { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
function SignIn() {
  const navigate = useNavigate();      

  const [formData, setFormData] = useState({
     
    email: '',
    password: '',
    role: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [registrationStatus, setRegistrationStatus] = useState(null);

  const handleFormSubmit = async (event) => {
    event.preventDefault();
    setIsSubmitting(true);
    try {
      const response = await axios.post('https://d2b2-139-135-32-3.ngrok-free.app/test/signin.php', formData, {
        headers: {
          'Content-Type': 'application/json'
        }
      });

      if (response.status === 200) {
        
        console.log("Successful")
        setRegistrationStatus('success');
        if (response.data.role === "admin") {
          console.log("Response data:", response.data);
          setTimeout(() => {
            setIsSubmitting(false);
            navigate('/adminpanel'); 
          }, 2000);
        } else if (response.data.role === "user"){
      console.log("Response data:", response.data); 
      setTimeout(() => {
        setIsSubmitting(false); 
        navigate('/userdashboard');
      }, 1000); // Delay navigation for 2 seconds
    }
    
    }
      else {
        setRegistrationStatus('failed');
        setIsSubmitting(false); // Stop loading
      }
    }catch (error) {
      console.error('Error submitting form:', error);
      setRegistrationStatus('failed');
      setIsSubmitting(false);
    }
  };

  const handleInputChange = (event) => {
    const { id, value } = event.target;
    setFormData((prevData) => ({
      ...prevData,
      [id]: value
    
    }));
     console.log(value);
    };
  return (
    <div>
     <div className='container-fluid'>
     <div className='row'>
     <div className='col-xl-9 col-lg-9 col-md-8 col-sm-6 img_back_form'> 
     <img src={heading_image} alt="Heading" className='image_headingsign' /> 

     </div>
     <div className="col-xl-3 col-lg-3 col-md-4 col-sm-6 form_back_col">
     <div><h1 className='signin_label pt-4 pb-5'>Sign In</h1></div>
    
     <form onSubmit={handleFormSubmit}>
     <div className="form-group mb-4">
      
       <TextField
         id="email"
         label="EMAIL ADDRESS"
         variant="outlined"
         fullWidth
         InputLabelProps={{
           className: 'custom-label'
         }}
          onChange={handleInputChange}
       />
     </div>
    
    
     <div className="form-group">
      
       <TextField
         id="password"
         label="PASSWORD"
         variant="outlined"
         type="password"
         fullWidth
         InputLabelProps={{
           className: 'custom-label'
         }}
         required 
         onChange={handleInputChange}
       />
     </div>
        
    
     <div className="form-group text-center pt-3 pb-3">
     <Link to="/forgot-password"> <a href="#forgot-password">Forgot Password?</a></Link>
      
     </div>
     <div className='container'> <button type="submit" className="w-100 btn btn-light btn_form">
     Sign In
   </button> </div>
   </form>
   
   </div>
     </div>
     </div>
    </div>
  )
}

export default SignIn
