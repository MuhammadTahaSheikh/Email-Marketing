import React from "react";
import ".././Packages/PackageEmail.css";

function PackagesEmail() {
  return (
    <div className="main_package">
      <section className="section" id="pricing">
        <div className="container">
          <div className="row">
            <div className="col-lg-12">
              <div className="title-box text-center">
                <h1 className="package_heading">PACKAGES</h1>
              </div>
            </div>
          </div>

          <div className="row mt-5 content_center">
            <div className="col-lg-4 col-md-8">
              <div className="pricing-box mt-4">
                <h4 className="f-20 st_pl">Starter Plan</h4>
                <p className="mb-2 f-18 pl_con">
                  Know more about the customer’s way
                </p>
                <div className="pricing-plan mt-4 pt-2">
                  <h4 className="text-muted">
                    <span className="plan pl-3 text-dark">
                      <b>$9</b>
                    </span>{" "}
                    <span className="mb-0 text-dark per_mon">per month</span>
                  </h4>
                </div>
                <div className="mt-4 pt-2 chooseplan_btn">
                  <a href="" className="btn choose_plan">
                    <b className="cho_plan">Choose this plan</b>
                  </a>
                </div>
                <div className="mt-4 pt-2">
                  <p className="mb-2 f-18">Features</p>

                  <p className="mb-2">
                    <i className="mdi mdi-checkbox-marked-circle text-primary f-18 mr-2"></i>
                    Payment terminals
                  </p>
                  <p className="mb-2">
                    <i className="mdi mdi-checkbox-marked-circle text-primary f-18 mr-2"></i>
                    Payment terminals
                  </p>
                  <p className="mb-2">
                    <i className="mdi mdi-checkbox-marked-circle text-primary f-18 mr-2"></i>
                    Payment terminals
                  </p>
                  <p className="mb-2">
                    <i className="mdi mdi mdi-close-circle-outline text-red f-18 mr-2"></i>
                    Payment terminals
                  </p>
                  <p className="mb-2">
                    <i className="mdi mdi mdi-close-circle-outline  f-18 mr-2"></i>
                    Payment terminals
                  </p>
                </div>
              </div>
            </div>
            <div className="col-lg-4 col-md-8">
              <div className="pricing-box1 mt-4">
                <p className="best_offer">Best Offer</p>

                <h4 className="f-20 text-white st_pl">Growth Plan</h4>
                <p className="mb-2 f-18 text-white pl_con">
                  Know more about the customer’s way
                </p>
                <div className="pricing-plan mt-4 pt-2">
                  <h4 className="text-muted ">
                    <span className="plan pl-3 text-white">
                      <b>$19</b>
                    </span>{" "}
                    <span className="mb-0 text-white per_mon">per month</span>
                  </h4>
                </div>
                <div className="mt-4 pt-2 chooseplan_btn bg-light">
                  <a href="" className="btn choose_plan">
                    <b className="cho_plan">Choose this plan</b>
                  </a>
                </div>
                <div className="mt-4 pt-2 text-white">
                  <p className="mb-2 f-18">Features</p>

                  <p className="mb-2">
                    <i className="mdi mdi-checkbox-marked-circle text-primary f-18 mr-2"></i>
                    Payment terminals
                  </p>
                  <p className="mb-2">
                    <i className="mdi mdi-checkbox-marked-circle text-primary f-18 mr-2"></i>
                    Payment terminals
                  </p>
                  <p className="mb-2">
                    <i className="mdi mdi-checkbox-marked-circle text-primary f-18 mr-2"></i>
                    Payment terminals
                  </p>
                  <p className="mb-2">
                    <i className="mdi mdi-checkbox-marked-circle text-primary f-18 mr-2"></i>
                    Payment terminals
                  </p>
                  <p className="mb-2">
                    <i className="mdi mdi-close-circle-outline f-18 mr-2"></i>
                    Payment terminals
                  </p>
                </div>
              </div>
            </div>

            <div className="col-lg-4 col-md-8">
              <div className="pricing-box mt-4">
                <h4 className="f-20 st_pl">Premium Plan</h4>
                <p className="mb-2 f-18 pl_con">
                  Know more about the customer’s way
                </p>
                <div className="pricing-plan mt-4 pt-2">
                  <h4 className="text-muted">
                    <span className="plan pl-3 text-dark">
                      <b>$29</b>
                    </span>{" "}
                    <span className="mb-0 text-dark per_mon">per month</span>
                  </h4>
                </div>
                <div className="mt-4 pt-2 chooseplan_btn">
                  <a href="" className="btn choose_plan">
                    <b className="cho_plan">Choose this plan</b>
                  </a>
                </div>
                <div className="mt-4 pt-2">
                  <p className="mb-2 f-18">Features</p>

                  <p className="mb-2">
                    <i className="mdi mdi-checkbox-marked-circle text-primary f-18 mr-2"></i>
                    Payment terminals
                  </p>
                  <p className="mb-2">
                    <i className="mdi mdi-checkbox-marked-circle text-primary f-18 mr-2"></i>
                    Payment terminals
                  </p>
                  <p className="mb-2">
                    <i className="mdi mdi-checkbox-marked-circle text-primary f-18 mr-2"></i>
                    Payment terminals
                  </p>
                  <p className="mb-2">
                    <i className="mdi mdi-close-circle text-primary text-red f-18 mr-2"></i>
                    Payment terminals
                  </p>
                  <p className="mb-2">
                    <i className="mdi mdi-close-circle text-primary f-18 mr-2"></i>
                    Payment terminals
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

export default PackagesEmail;
