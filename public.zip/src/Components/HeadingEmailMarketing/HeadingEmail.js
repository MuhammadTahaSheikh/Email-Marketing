import React from 'react';
import heading_image from "../../Assets/heading_image.png";
import "./HeadingEmail.css"; 

function HeadingEmail() {
  return (
    <div className="test">
      <div className="container-fluid">
        <div className="row">
          <div className="col-2">
            <h1 className="centered-heading">Heading</h1>
          </div>
          <div className="col-sm">
          </div>
          <div className="col-8">
            <img src={heading_image} alt="Heading" className='image_heading' />
          </div>
        </div>
      </div>
    </div>
  );
}

export default HeadingEmail;
