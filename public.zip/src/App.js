import React from 'react';
import { BrowserRouter as Router, Route, Routes, Redirect } from 'react-router-dom';

import '@fortawesome/fontawesome-free/css/all.min.css';
import HomePage from './Components/HomePageEmail/HomePage';
import SignIn from './Components/SignInUp/SignIn';
import SignUp from './Components/SignInUp/SignUp';
import ForgetPassword from './Components/SignInUp/ForgetPassword';
import AdminPanelEmailMarketing from './Components/AdminPanelEmailMarketing/AdminPanelMain';
import BillingHistoryRecord from './Components/BillingEmailMarketing/BillingHistoryRecord';
import BillingHistoryUserTable from './Components/BillingEmailMarketing/BillingHistoryUserTable';
import UserDashboardBilling from './Components/UserDashboardEmailMarketing/UserDashboardBilling';
import UserDashboardAll from './Components/UserDashboardEmailMarketing/UserDashboardAll';
import AdminPanel from './Components/AdminPanel';
import AdminBillingPanel from './Components/AdminBillingPanel';
import BillingHistory from './Components/BillingEmailMarketing/BillingHistory';

function App() {
  return (
    <Router>
   
      <Routes>
    
        <Route exact path="/"  element={<HomePage/>} />
        <Route path="/signin" element={<SignIn/>} />
        <Route path="/signup" element={<SignUp/>} />
        <Route path="/forgot-password" element={<ForgetPassword/>} />
        <Route path="/signin" element={<SignIn/>} />
        <Route exact path="/adminpanel"  element={<AdminPanel/>} />
        <Route exact path="/userdashboard"  element={<UserDashboardAll/>} />
        <Route exact path="/billinghistory" element={<BillingHistory/>} />
      </Routes>
    </Router>
  );
}

export default App;
                                           